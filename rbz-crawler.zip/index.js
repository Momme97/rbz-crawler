const shopRequester = require('./shopRequester');
const mongoDbHandler = require('./mongoDBHandler');
const moment = require('moment'); // require
const CronJob = require('cron').CronJob;

let findCrawlData = async () => {
    let urlList = await mongoDbHandler.getUrlCrawlData();
    let resultArray = [];

    for(let i = 0; i < urlList.length; i++){
        resultArray.push({productName:urlList[i].productName,vendor:"Alternate",price: await shopRequester.shopRequester('Alternate',urlList[i].urlAlternate),timestamp: moment().format()});
        resultArray.push({productName:urlList[i].productName,vendor:"Expert",price: await shopRequester.shopRequester('Expert',urlList[i].urlExpert),timestamp: moment().format()});

    }
    console.log(resultArray);
    mongoDbHandler.insertOrUpdateData(resultArray);
}
var job = new CronJob('0 * * * *', function() {
    findCrawlData();
}, null, true, 'America/Los_Angeles');
job.start();


